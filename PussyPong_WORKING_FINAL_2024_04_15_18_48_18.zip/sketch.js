let Redlip;
let Blueball;
let ball;
let leftPaddle;
let rightPaddle;
let pussyImage;
let pussyFlashTimer;
let confetti = [];
let audio;

function preload() {
  Redlip = loadImage('Redlip.png');
  Blueball = loadImage('Blueball.png');
  pussyImage = loadImage('Pussy.png');
  audio = loadSound('Pussyaudio.mp3');
  audio.setVolume(1.5);
}

function setup() {
  createCanvas(800, 400);
  ball = new Ball();
  leftPaddle = new Paddle(true, 20, height / 2);
  rightPaddle = new Paddle(false, width - 20, height / 2);
  pussyFlashTimer = 0;
  for (let i = 0; i < 100; i++) {
    confetti.push(new Confetti());
  }
}

function draw() {
  background(0);

  ball.update();
  ball.show();

  leftPaddle.show();
  leftPaddle.update();

  rightPaddle.show();
  rightPaddle.update(mouseY);

  checkCollision(leftPaddle);
  checkCollision(rightPaddle);

  if (ball.x - ball.radius < 0 || ball.x + ball.radius > width) {
    if (!pussyFlashTimer) {
      pussyFlashTimer = frameCount;
      audio.play();
    }
  }

  if (pussyFlashTimer && frameCount - pussyFlashTimer < 300) { // 300 frames = 5 seconds at 60 FPS
    image(pussyImage, 0, 0, width, height);
    for (let confettiParticle of confetti) {
      confettiParticle.show();
      confettiParticle.update();
    }
  } else if (pussyFlashTimer) {
    resetGame();
  }
}

function checkCollision(paddle) {
  if (ball.x + ball.radius > paddle.x &&
    ball.x - ball.radius < paddle.x + paddle.width &&
    ball.y + ball.radius > paddle.y - paddle.height / 2 &&
    ball.y - ball.radius < paddle.y + paddle.height / 2) {
    ball.xSpeed *= -1;
  }
}

function resetGame() {
  pussyFlashTimer = 0;
  ball = new Ball();
  confetti = [];
  for (let i = 0; i < 100; i++) {
    confetti.push(new Confetti());
  }
}

class Ball {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.radius = 20;
    this.xSpeed = random(-3, 3);
    this.ySpeed = random(-3, 3);
  }

  update() {
    this.x += this.xSpeed;
    this.y += this.ySpeed;

    if (this.y < 0 || this.y > height) {
      this.ySpeed *= -1;
    }
  }

  show() {
    image(Blueball, this.x - this.radius, this.y - this.radius, this.radius * 2, this.radius * 2);
  }
}

class Paddle {
  constructor(isLeft, x, y) {
    this.isLeft = isLeft;
    this.x = x;
    this.y = y;
    this.width = 20;
    this.height = 100;
  }

  show() {
    if (this.isLeft) {
      image(Redlip, this.x - this.width / 2, this.y - this.height / 2, this.width, this.height);
    } else {
      image(Redlip, this.x - this.width / 2, this.y - this.height / 2, this.width, this.height);
    }
  }

  update(y) {
    this.y = y;
  }
}

class Confetti {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(5, 15);
    this.speed = random(1, 3);
    this.color = color(random(255), random(255), random(255));
  }

  show() {
    noStroke();
    fill(this.color);
    ellipse(this.x, this.y, this.size, this.size);
  }

  update() {
    this.y += this.speed;
    if (this.y > height) {
      this.y = 0;
      this.x = random(width);
    }
  }
}